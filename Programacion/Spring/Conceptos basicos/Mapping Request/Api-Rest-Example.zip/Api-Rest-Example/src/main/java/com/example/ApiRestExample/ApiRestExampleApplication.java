package com.example.ApiRestExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestExampleApplication.class, args);
	}

}
