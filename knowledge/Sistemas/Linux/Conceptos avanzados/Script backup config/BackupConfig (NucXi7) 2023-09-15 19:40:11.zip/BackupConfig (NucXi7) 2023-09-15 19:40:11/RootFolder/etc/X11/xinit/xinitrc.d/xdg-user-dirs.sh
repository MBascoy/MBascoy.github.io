#!/bin/sh
/usr/bin/xdg-user-dirs-update
