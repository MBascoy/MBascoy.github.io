
/* Do some formatting on query (thanks google.com). */
function qs(el) {
   if (window.RegExp && window.encodeURIComponent)
   {
      var qe=encodeURIComponent(document.f.q.value);
      if (el.href.indexOf("q=")!=-1)
      {
	 el.href=el.href.replace(new RegExp("q=[^&$]*"),"q="+qe);
      }
      else
      {
	 el.href+="&q="+qe;
      }
   }
   return 1;
}

function validateString(str, warning, min, max) {
   if (!min) { min = 1; }
   if (!max) { max = 65535; }

   if (!str.value || str.value.length < min || str.value.length > max) {
      alert(unescape(warning));
      str.focus();
      str.select();
      return false;
   }
   return true;
}


function validateEmail(email) {
   if (!email.value) {
      return true;
   }

   var re_mail = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z])+$/;
   if (!re_mail.test(email.value)) {
      alert('Invalid email address.  Maybe you typed it wrong?');
      email.focus();
      email.select();
      return false;
   }
   return true;
}

function reloadImage(id) {
   img = document.getElementById(id);
   var date = new Date();
   img.src = img.src + '?ts=' + date.getTime();
   return true;
}
