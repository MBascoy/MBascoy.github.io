Backup creado el 2026-02-24 14:57:34 del equipo (NucXi7)


Esta carpeta contiene un backup de los siguientes elementos:

  -BU-log que muestra el log de salida de cuando se creó este backup (si se muestra con 'cat' se mostrarán en verde lo que ha ido bien y en rojo lo que ha ido mal) (Carpeta raiz)
  -Contenido de la carpeta /etc/alternatives en el archivo alternatives.txt, el archivo mantiene el esquema de colores del shell, se pueden visualizar usando cat (Carpeta raiz)

  -Listado de paquetes RPM instalados (Carpeta RPM List)
  -Listado de paquetes RPM con fallos de verificación y una copia de dichos archivos con cambios (Carpeta RPM List)
  -Listado de paquetes DEB instalados (Archivo devList.txt)
  -Log dmesg (Carpeta raiz)
  -Archivo environment.txt con el contenido de las variables de entorno (Carpeta raiz)
  -La carpeta 'paths' contiene archivos con el contenido que tienen todas las rutas declaradas en la variable de entorno PATH 


En la carpeta 'RootFolder' se encuentran todos los archivos copiados manteniendo su ruta original en el sistema de archivos (teniendo como referencia de la raiz dicha carpeta RootFolder), los archivos que se guardan en esta carpeta son:

  -Carpeta /etc/X11
  -Carpeta /etc/zypp/repos.d
  -Archivo /etc/profile
  -Archivo /var/log/Xorg.0.log
  -Carpeta /usr/share/xsessions/


La carpeta del usuario se identifica con /home/usuario (independientemente del nombre del usuario real), los archivos que contiene son (Hay archivos que son ocultos, pero en esta copia se ponen sin el punto inicial para que aparezcan visible):

  -Archivo bashrc del usuario
  -Archivo profile del usuario
  -Archivo .config/kdeglobals del usuario
  -Archivo .config/kdedefaults del usuario
